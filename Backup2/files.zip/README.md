# FIFA World Cup 2026 Live Dashboard (IST)

A web application showing **live FIFA World Cup 2026** scores, status, and schedule, sourced in real time from TheSportsDB API, with all match times converted to **Indian Standard Time (IST)** (or any timezone you pick).

## Features

✨ **Key Features:**
- 🔴 **Live scores & status** — LIVE / HT / FT / SCHEDULED, refreshed automatically every 30 seconds
- 🌍 **Timezone conversion** — match times shown in IST by default, switchable to GMT/ET/PT
- 🔍 **Search** — filter matches by team name in real time
- 🕓 **"Updated at" indicator** — shows when the data was last refreshed from the live feed
- 📱 **Responsive design** — mobile, tablet, desktop
- 🎨 **Dark UI** with Tailwind CSS

## Architecture

This app is **not** a static site — `server.js` is required and does the real work:

```
script.js (browser)
   │  polls /api/matches every 30s
   ▼
server.js (Node/Express)
   │  refreshes its own in-memory cache every 30s
   │  (clients never trigger an upstream call directly)
   ▼
TheSportsDB API (eventspastleague / eventsnextleague / livescore)
```

`server.js` merges three TheSportsDB endpoints (finished matches, upcoming matches, and live-in-play matches) into one normalized match list, caches it server-side, and serves it to the frontend via `/api/matches`. This avoids hammering the upstream API and means many simultaneous users only cost you one upstream refresh cycle, not one per user.

**`matches.deprecated.json`** is the original static fixture list. It is **no longer used by the running app** — kept only for reference. All fixture data, scores, and status now come live from the API.

## Tech Stack

- **Node.js / Express** — backend, live data fetching & caching
- **TheSportsDB API** — live World Cup data (League ID `4429`)
- **HTML5 / Tailwind CSS** — structure & styling
- **Vanilla JavaScript** — frontend rendering, search, timezone handling

## Project Structure

```
fifa26/
├── server.js                # Express backend — fetches & caches live match data
├── test-api.js               # Standalone diagnostic: verifies TheSportsDB responses
├── public/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── matches.deprecated.json   # Old static data — unused, kept for reference
└── README.md
```

*(Express serves static files from a `public/` folder — make sure `index.html`, `styles.css`, and `script.js` live there, or adjust `server.js`'s static path.)*

## Getting Started

### Prerequisites
- Node.js installed
- Internet access (the server calls TheSportsDB live)

### Installation

```bash
npm install express cors dotenv
node server.js
```

Then open `http://localhost:3000` in your browser.

### Verifying the live data feed

Before trusting the dashboard, run the diagnostic script once to confirm TheSportsDB is returning real data for your environment:

```bash
node test-api.js
```

This checks the past/next/live endpoints independently and prints a sample event from each, so you can catch upstream API issues (rate limits, empty responses, schema changes) before they show up silently in the UI.

You can also check `http://localhost:3000/api/health` at any time to see the backend's cache status without opening the full dashboard.

## Match Data Shape

Internally, every match (regardless of source) is normalized to:

```json
{
  "id": "12345",
  "timeUTC": "2026-06-11T18:00:00Z",
  "status": "LIVE",
  "stage": "Group Stage",
  "stadium": "Estadio Azteca",
  "city": "Mexico City",
  "team1": "Mexico",
  "team2": "Japan",
  "score": { "home": 1, "away": 0 }
}
```

- **status**: one of `SCHEDULED`, `LIVE`, `HT`, `FT`, `POSTPONED`, `CANCELLED`
- **score.home / score.away**: `null` until the match has actually started — this is what tells the frontend to show "VS" instead of "0 - 0"

## Known Limitations

- TheSportsDB's free tier can rate-limit or restrict live in-play data; if `/api/health` shows a stale `lastUpdated` or matches stuck on `SCHEDULED` during a known live match, check the upstream API status before assuming the app is broken.
- Team names from the API may not always match the `flags` lookup table in `script.js` exactly — if a flag is missing for a team, add its normalized name to that table.

## Browser Support

- ✅ Chrome/Chromium (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)

## License

MIT License.

## Author

Built with ⚽ by [srinfinityvlogs](https://github.com/srinfinityvlogs)
