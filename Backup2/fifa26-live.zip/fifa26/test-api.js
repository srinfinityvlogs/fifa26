// Quick diagnostic — run this once locally with `node test-api.js`
// to confirm what TheSportsDB actually returns for your free-tier key
// before trusting the merged feed.

const BASE = "https://www.thesportsdb.com/api/v1/json/3";
const LEAGUE_ID = "4429";

async function check(label, url) {
  try {
    const res = await fetch(url);
    const data = await res.json();
    const events = data.events || [];
    console.log(`\n--- ${label} ---`);
    console.log(`Status: ${res.status} | Events returned: ${events.length}`);
    if (events[0]) {
      console.log("Sample event:", JSON.stringify({
        idEvent: events[0].idEvent,
        strHomeTeam: events[0].strHomeTeam,
        strAwayTeam: events[0].strAwayTeam,
        strStatus: events[0].strStatus,
        dateEvent: events[0].dateEvent,
        intHomeScore: events[0].intHomeScore,
        intAwayScore: events[0].intAwayScore,
      }, null, 2));
    }
  } catch (err) {
    console.log(`\n--- ${label} ---`);
    console.log("FAILED:", err.message);
  }
}

(async () => {
  await check("PAST (eventspastleague)", `${BASE}/eventspastleague.php?id=${LEAGUE_ID}`);
  await check("NEXT (eventsnextleague)", `${BASE}/eventsnextleague.php?id=${LEAGUE_ID}`);
  await check("LIVE (livescore, all soccer)", `${BASE}/livescore.php?l=Soccer`);
})();
